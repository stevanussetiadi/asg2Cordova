var dbHandler = {
    db: null,
    createDatabase: function(){ //transaction for creating database in WebSql (not mysql database)
        this.db = window.openDatabase("seasales.db", "1.0","sea store database", 1000000); //to connect the database 
        this.db.transaction(
            function(tx){
                tx.executeSql("drop table if exists users"); //delete table user if exist
                tx.executeSql("create table if not exists users(_id integer primary key, user text, pass text)"); //create table user if not exist
                tx.executeSql("insert into users (user,pass) values('user1','user1')"); //insert some user data 
                tx.executeSql("insert into users (user,pass) values('user2','user2')");
                tx.executeSql("insert into users (user,pass) values('user3','user3')");
                tx.executeSql("insert into users (user,pass) values('staff1','staff1')");
                tx.executeSql("insert into users (user,pass) values('staff2','staff2')");
                tx.executeSql("insert into users (user,pass) values('staff3','staff3')");
            },
            function(error){
                console.log("error: "+error.message); //if there is error in the first proccess 
            },
            function(){
                console.log("Create User Completed");// if the transaction process is run successfully 
            }
        );
    }
}
var prdHandler = {
    addProduct: function(){ //transaction for creating table product
        dbHandler.db.transaction(
            function(tx){
                tx.executeSql("drop table if exists products"); //delete table product if exist
				tx.executeSql("create table if not exists products(_id integer primary key, prdno text, name text, type text, serial text, price double, features text, warranty text)"); //create table product if not exist
                //insert some product data
				tx.executeSql("insert into products (prdno, name, type, serial, price, features, warranty) values ('MW1', 'ELECTROLUX EMM2318X MICROWAVE WITH GRILL (23L)', 'MICROWAVE', 'SKUIP097021', 299.99, 'Total Capacity: 23L. Power Consumption: Grill / MWO. Power (W): 1000 / 800. Timers: Yes, up to 35 minutes.', '1 Year')");
				tx.executeSql("insert into products (prdno, name, type, serial, price, features, warranty) values ('MW2', 'EUROPACE EMW1201S MICROWAVE OVEN (20L)', 'MICROWAVE', 'SKUIP117582', 299.99, 'Total Capacity: 20L. Power Consumption: 1050W. Timers: 35mins.', '1 Year')");
				tx.executeSql("insert into products (prdno, name, type, serial, price, features, warranty) values ('MW3', 'PANASONIC NNST25JWYPQ MICROWAVE OVEN 20L', 'MICROWAVE', 'SKUIP143637', 299.99, 'Total Capacity: 20L. Power Consumption: 800W.', '1 Year')");
				tx.executeSql("insert into products (prdno, name, type, serial, price, features, warranty) values ('MW4', 'SHARP R-219T(S) SOLO MICROWAVE OVEN (22L) (SILVER)', 'MICROWAVE', 'SKUIP159463', 299.99, 'Total Capacity: 22L. Power Consumption: 800W.', '1 Year')");
				tx.executeSql("insert into products (prdno, name, type, serial, price, features, warranty) values ('MW5', 'TOSHIBA M20P(BK) MICROWAVE (20L)', 'MICROWAVE', 'SKUIP152794', 299.99, 'Total Capacity: 22L. Power Consumption: 800W.', '1 Year Carry In')");
				tx.executeSql("insert into products (prdno, name, type, serial, price, features, warranty) values ('MW6', 'SHARP R-22A0(SM)V SOLO MICROWAVE OVEN (20L)', 'MICROWAVE', 'SKUIP159462', 299.99, 'Total Capacity: 20L. Power Consumption: 800W.', '1 Year')");
				tx.executeSql("insert into products (prdno, name, type, serial, price, features, warranty) values ('MW7', 'MIDEA AM823ABV SOLO MICROWAVE OVEN (23L)', 'MICROWAVE', 'SKUIP159463', 299.99, 'Total Capacity: 23L. Power Consumption: 800W.', '1 Year Carry In')");
				tx.executeSql("insert into products (prdno, name, type, serial, price, features, warranty) values ('MW8', 'SHARP R-62E0(S) MICROWAVE OVEN WITH GRILL (20L)', 'MICROWAVE', 'SKUIP159461', 299.99, 'Total Capacity: 20L. Power Consumption: 1000W.', '1 Year')");
				tx.executeSql("insert into products (prdno, name, type, serial, price, features, warranty) values ('MW9', 'TOSHIBA MMEM25P SOLO MICROWAVE OVEN (25L)', 'MICROWAVE', 'SKUIP150221', 299.99, 'Total Capacity: 25L. Power Consumption: 900W.', '1 Year')");
				tx.executeSql("insert into products (prdno, name, type, serial, price, features, warranty) values ('MW10', 'SAMSUNG MS23K3513AK/SP MICROWAVE OVEN (23L)', 'MICROWAVE', 'SKUIP150304', 299.99, 'Total Capacity: 23L. Power Consumption: 1150W. Timers: Yes.', '1 Year')");
				tx.executeSql("insert into products (prdno,name,type,serial,price,features,warranty) values('RF1','MIDEA MRM584S SIDE BY SIDE FRIDGE (GROSS 584L)','REFRIGERATOR','SKUIP119200',299.99,'Total Capacity: 584l (gross) 515l (net). Dimensions (W x H x D): 895 X 1788 X 745. Eco-friendly Certification(s): 2 Ticks. Eco-friendly Features: R600a','1 Year')");
                tx.executeSql("insert into products (prdno,name,type,serial,price,features,warranty) values('RF2','MIDEA CE-BCD640WE-JT INVERTER SIDE BY SIDE FRIDGE (NET 610L)','REFRIGERATOR','SKUIP159841',299.99,'Total Capacity: 610l. Dimensions (W x H x D): 910 X 1808 X 750. Eco-friendly Certification(s): 3 Ticks. Eco-friendly Features: Infinite Inverter. Reversible Door Swing: No.','1 Year')");
                tx.executeSql("insert into products (prdno,name,type,serial,price,features,warranty) values('RF3','MIDEA MRM640S INVERTER SIDE BY SIDE FRIDGE (NET 610L)','REFRIGERATOR','SKUIP159542',299.99,'Total Capacity: 610l. Dimensions (W x H x D): 910 X 1808 X 750. Eco-friendly Certification(s): 3 Ticks. Eco-friendly Features: Infinite Inverter. Reversible Door Swing: No.','1 Year')");
                tx.executeSql("insert into products (prdno,name,type,serial,price,features,warranty) values('RF4','SAMSUNG RT53K6257SL/SS 2 DR FRIDGE (GROSS 543L)','REFRIGERATOR','SKUIP108047',299.99,'Total Capacity: (gross) 543l (net) 528l. Dimensions (W x H x D): 790x1855x720. Eco-friendly Certification(s): 3 Ticks. Eco-friendly Features: Inverter Compressor. Reversible Door Swing: No.','1 Year')");
                tx.executeSql("insert into products (prdno,name,type,serial,price,features,warranty) values('RF5','SAMSUNG RT53K6257BS/SS 2 DR FRIDGE (GROSS 543L)','REFRIGERATOR','SKUIP108048',299.99,'Total Capacity: 543l (gross) 528l (net). Dimensions (W x H x D): 790 X 1855 X 720mm. Eco-friendly Certification(s): 3 Ticks. Eco-friendly Features: Inverter Compressor. Reversible Door Swing: No.','1 Year')");
                tx.executeSql("insert into products (prdno,name,type,serial,price,features,warranty) values('RF6','MIDEA MRD268 2 DR FRIDGE (GROSS 270L)','REFRIGERATOR','SKUIP116752',299.99,'Total Capacity: 270l (gross) 254 L (net). Dimensions (W x H x D): 545 X 1657 X 623. Eco-friendly Certification(s): Mels-mid-160080 / 2 Ticks. Eco-friendly Features: R600a. Reversible Door Swing: No.','1 Year')");
                tx.executeSql("insert into products (prdno,name,type,serial,price,features,warranty) values('RF7','SAMSUNG RT25FARADSA/SS 2 DR FRIDGE (GROSS 264L)','REFRIGERATOR','SKUIP069401',299.99,'Total Capacity: (gross) 264l (net) 255l. Dimensions (W x H x D): 555x1635x637. Eco-friendly Certification(s): 2 Ticks. Eco-friendly Features: Inverter Compressor. Reversible Door Swing: No.','1 Year')");
                tx.executeSql("insert into products (prdno,name,type,serial,price,features,warranty) values('RF8','MIDEA MDRT93WEDMX02 BAR FRIDGE (NET 93L)','REFRIGERATOR','SKUIP153591',299.99,'Total Capacity: 93l. Dimensions (W x H x D): 472 X 850 X 450. Eco-friendly Certification(s): 2 Ticks. Reversible Door Swing: No.','1 Year')");
                tx.executeSql("insert into products (prdno,name,type,serial,price,features,warranty) values('RF9','HITACHI RH240P7MSBBK 2 DR FRIDGE (NET 203L)','REFRIGERATOR','SKUIP141630',299.99,'Total Capacity: 203l (net). Dimensions (W x H x D): 540 X 1640 X 650. Eco-friendly Certification(s): 2 Ticks. Eco-friendly Features: Inverter Control, Eco Thermo. Reversible Door Swing: No.','1 Year')");
                tx.executeSql("insert into products (prdno,name,type,serial,price,features,warranty) values('RF10','ELECTROLUX ETB2802HA 2 DR FRIDGE (GROSS 260L)','REFRIGERATOR','SKUIP141630',299.99,'Total Capacity: 256l(net). Dimensions (W x H x D): 540 X 1605 X 615. Eco-friendly Certification(s): Energy Efficiency (mels) - 2. Reversible Door Swing: No.','1 Year')");
                tx.executeSql("insert into products (prdno,name,type,serial,price,features,warranty) values('WM1','WHIRLPOOL WVFC750AJGR TOP LOAD WASHER (7.5KG) 6TH SENSE STAIN WASH','WASHING MACHINE','SKUIP159264',299.99,'Dimensions (W x H x D): 520 x 535 x 907 mm. Spin Speed: 850Rpm. Water Efficiency: 3 TICKS. Safety Features: Child Lock.','2 Years')");
                tx.executeSql("insert into products (prdno,name,type,serial,price,features,warranty) values('WM2','PANASONIC NAF75S7HRQ TOP LOAD WASHER (7.5KG)','WASHING MACHINE','SKUIP153041',299.99,'Dimensions (W x H x D): 525 x 571 x 929 mm. Spin Speed: 700Rpm. Water Efficiency: 3 Ticks/8.60 litres/kg/WM-2015/017387. Safety Features: Child lock.','1 Year')");
                tx.executeSql("insert into products (prdno,name,type,serial,price,features,warranty) values('WM3','MIDEA MT850B TOP LOAD WASHER (8KG)','WASHING MACHINE','SKUIP137955',299.99,'Dimensions (W x H x D): 550 x 920 x 565mm. Spin Speed: 700Rpm. Water Efficiency: 3 Ticks/ 9 Litres /kg / WM-2016/020754. Safety Features: Child Lock.','2 Years Full Warranty And 6 Years On Motor')");
                tx.executeSql("insert into products (prdno,name,type,serial,price,features,warranty) values('WM4','ELECTROLUX EWT7588H1WB TOP LOAD WASHER (7.5KG)','WASHING MACHINE','SKUIP161582',299.99,'Dimensions (W x H x D): 515 x 930 x 525 mm. Drum and Interior Finish: Prism Drum. Water Efficiency: Water efficiency (WELS) - 3 ticksWater consumption: 6.70 L/. Safety Features: Child Lock, Soft Closing.','2 Years')");
                tx.executeSql("insert into products (prdno,name,type,serial,price,features,warranty) values('WM5','MIDEA MT950B TOP LOAD WASHER (9KG)','WASHING MACHINE','SKUIP121805',299.99,'Dimensions (W x H x D): 550 x 960 x 565 mm. Spin Speed: 1000Rpm. Water Efficiency: 3 Ticks/ 8.0 Litres/kg / WM-2016/020753. Safety Features: Child Lock.','2 Years Full Warranty And 6 Years On Motor')");
                tx.executeSql("insert into products (prdno,name,type,serial,price,features,warranty) values('WM6','TECNO TWA8088 TOP LOAD WASHER (8KG)','WASHING MACHINE','SKUIP109364',299.99,'Dimensions (W x H x D): 580 x 960 x 585 mm. Drum and Interior Finish: Stainless steel. Spin Speed: 900rpm. Water Efficiency: 3 Ticks 8.00 litres/kg / WM-2015/018657. Safety Features: Child Lock.','1 Year')");
                tx.executeSql("insert into products (prdno,name,type,serial,price,features,warranty) values('WM7','PANASONIC NAF80VB7HRQ TOP LOAD WASHER (8KG)','WASHING MACHINE','SKUIP157064',299.99,'Dimensions (W x H x D): 562 x 929 x 571 mm. Drum and Interior Finish: Stainless Steel. Spin Speed: 700Rpm. Water Efficiency: 3 Ticks/7.80 litres/kg/WM-2019/027628/TUV. Safety Features: Child lock.','1 Year')");
                tx.executeSql("insert into products (prdno,name,type,serial,price,features,warranty) values('WM8','TECNO TWA7078 TOP LOAD WASHER (7KG)','WASHING MACHINE','SKUIP109363',299.99,'Dimensions (W x H x D): 580 x 945 x 585 mm. Drum and Interior Finish: Stainless steel. Spin Speed: 800Rpm. Water Efficiency: 3 Ticks 7.90 litres/kg / WM-2015/018811. Safety Features: N/A.','1 Year')");
                tx.executeSql("insert into products (prdno,name,type,serial,price,features,warranty) values('WM9','BEKO WTE7512B0 FRONT LOAD WASHER (7KG)','WASHING MACHINE','SKUIP109363',299.99,'Dimensions (W x H x D): 600 x 840 x 490 mm. Drum and Interior Finish: Stainless Steel. Spin Speed: 1000 Rpm. Water Efficiency: 3 Ticks/6.32 litres/kg/WM-2019/026550/SET. Safety Features: Overflow Safety , Child Lock.','2 Years (Full), 3rd Year (Parts), 5 Years (Motor)')");
                tx.executeSql("insert into products (prdno,name,type,serial,price,features,warranty) values('WM10','PANASONIC NA-F100A4BRQ TOP LOAD WASHER (10KG)','WASHING MACHINE','SKUIP162119',299.99,'Dimensions (W x H x D): 554 x 1035 x 617mm. Drum and Interior Finish: Plastic. Spin Speed: NA. Water Efficiency: 3 Ticks/6.40litres/kg/WM-2020/029992/TUV.','1 year')");
            },
            function(error){
                console.log("error: "+error.message); //if any error happen while running the transaction 
            },
            function(){
                console.log("Create Product Completed"); // if all transaction completed 
            }
        );
    },
    slcProduct: function(ctg,callback){ //it is a function to collecting data from product table in specified category
        var items = new Array();
        dbHandler.db.transaction(
        function(tx){
            var sql = "select * from products where type = '"+ctg+"'";
            tx.executeSql(sql,[],
            function(tx,results){ //if the query succeeds and the result return to the caller function with callback 
                var ln = results.rows.length;
                console.log(results);
                for(var i = 0; i<ln; i++){
                    items.push(results.rows.item(i));
                }
                callback (items) //return the result to the caller function 
            },
              function(error){
               console.log("error: "+error.message); // if there is any error while running the query    
            });
        },
             function(error){
                console.log("error: "+error.message); //if any error happen while running the transaction 
            },
            function(){
                console.log("Select product Completed"); //if the transaction succeeds
            }
        );
    }
    
}
var trxHandler={
    crtTrans: function(){ // a function to create transaction table
        dbHandler.db.transaction(
        function(tx){
            tx.executeSql("drop table if exists trans"); // 
                tx.executeSql("create table if not exists trans(_id integer primary key,prdno text, name text,qty integer, price double,total double)");
        },
             function(error){
                console.log("error: "+error.message);
            },
            function(){
                console.log("Create Transaction Completed");
            }
        );
    },
      addTrans: function(nop,nme,num,prc){ //function to insert data into transaction table 
        dbHandler.db.transaction(
        function(tx){
            var total = num*prc;
             tx.executeSql("insert into trans (prdno,name,qty,price,total) values(?,?,?,?,?)",[nop,nme,num,prc,total],
             function(tx,results){
                 alert("buying transaction added")
             },
                function(error){
                console.log("error: "+error.message);
            });
        }

        );
    },
     slcTrans: function(callback){ //function for collecting data from transaction table
        var items = new Array();
        dbHandler.db.transaction(
        function(tx){
            var sql = "select * from trans ";
            tx.executeSql(sql,[],
            function(tx,results){
                var ln = results.rows.length;
                console.log(results);
                for(var i = 0; i<ln; i++){
                    items.push(results.rows.item(i));
                }
                callback (items) //return the result to the caller function 
            },
              function(error){
               console.log("error: "+error.message);    
            });
        },
             function(error){
                console.log("error: "+error.message);
            },
            function(){
                console.log("Select transaction Completed");
            }
        );
    }
}
var msgHandler={
    crtMsg: function(){ //function to create message table 
        dbHandler.db.transaction(
        function(tx){
            tx.executeSql("drop table if exists messages");
                tx.executeSql("create table if not exists messages(_id integer primary key, first text, last text, country text,subject text)");
        },
             function(error){
                console.log("error: "+error.message);
            },
            function(){
                console.log("Create messages Completed");
            }
        );
    },
     addMsg: function(frs,lst,ctr,msg){ //function to insert message into the message table 
        dbHandler.db.transaction(
        function(tx){
             tx.executeSql("insert into messages (first,last,country,subject) values(?,?,?,?)",[frs,lst,ctr,msg],
             function(tx,results){
                 alert("message added")
             },
                function(error){
                console.log("error: "+error.message);
            });
        }

        );
    }
}
var Log = {
    verify: function(usr,pwd){ //function to verify username and password when someone logging in 
        dbHandler.db.transaction(
        function(tx){
             tx.executeSql("select * from users where user = ? and pass = ?",[usr,pwd], //try to search data in user table  according to username and password inputed by user
             function(tx,results){
                 var len = results.rows.length;
                 if (len>0){ // if length result is more than zero it means that the username existed. 
                     alert("Welcome, "+usr);
                     if(usr == "admin"){
                        window.location = "admain.html"; //jump to admin page 
                        } else{
                            window.location= "main.html"; //display user page
                        }
                     }else{ //if length result equals zero, it means the username for password is invalid
                         alert("Invalid Username/Password");
                         $("#username").val("");
                         $("#password").val("");
                     }
             },
                function(error){
                console.log("error: "+error.message); //if the query error
            });
        }

        );
    }, 
    register: function(usr,pwd){ //function to insert new user table
        dbHandler.db.transaction(
        function(tx){
             tx.executeSql("insert into users (user,pass) values(?,?)",[usr,pwd],
             function(tx,results){
                 alert("user " +usr+" added")
             },
                function(error){
                console.log("error: "+error.message);
            });
        }

        );
    }
}
