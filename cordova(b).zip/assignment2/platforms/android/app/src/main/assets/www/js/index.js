$(document).on("ready",function(){ //function that is run when index.js is called
    // call some functions in db.js
    dbHandler.createDatabase();
    prdHandler.addProduct();
    trxHandler.crtTrans();
    msgHandler.crtMsg();
});
function verLog(){ //function to verify the value of username and password inputs in html page and send them to verify function in db.js
    var usr = $("#username").val(); 
    var pwd = $("#password").val();
    Log.verify(usr,pwd);
    $("#username").val("");
    $("#password").val("");
}
function verReg(){ //function to collect username and password for new user and send them to register function in db.js
    var usr = $("#userreg").val();
    var pwd = $("#passreg").val();
    Log.register(usr,pwd);
    $("#userreg").val("");
    $("#passreg").val("");
}
function svMsg(){ //function to collect data for new message and send them to save message function in db.js
    var frs = $("#first").val();
    var lst = $("#last").val();
    var ctr = $("#country").val();
    var msg = $("#message").val();
    msgHandler.addMsg(frs,lst,ctr,msg);
    $("#first").val("");
    $("#last").val("");
    $("#country").val("");
    $("#message").val("");
}
function selPrd(callback){ //a function to call function in db.js for collecting data product and process the return items to display in html page 
    var items = new Array();
    var ctg = $("#cmbprd").val();
    if (ctg == "---"){
        $('#prdcnt').html("<h4>Please choose type above</h4>");
    }else{
        prdHandler.slcProduct(ctg,function(items){ //call select product function by sending category and receive return value items
            // preparing the return value items to be displayed in html page. 
            var tmp = "";
            items.forEach(obj => {
                var temp = "<div data-role = 'content' class = 'ui-content'>";
                Object.entries(obj).forEach(([key,value]) => {
                    switch(`${key}`){
                        case "_id": break;
                        case "type": break;
                        case "prdno": temp+= "<img src = 'img/"+`${value}`+".jpg' width = '100px' alt = '"+`${value}`+"'/>"; break;
                        case "name": temp+= "<h3>"+`${value}`+"</h3>"; break;
                        case "price": temp+= "<h4> Price: $"+`${value}`+"</h4>"; break;
                        default:
                            temp+= "<p>"+`${key}`+": "+`${value}`+"</p>";
                    }
                });
                temp+= "</div>";
                tmp+=temp;
            });
            $("#prdcnt").html(tmp); //send prepared items to display in html page 
        });
            
        
    }
}
function buyPrd(callback){ //a function to call function in db.js for buying process 
    var items = new Array();
    var ctg = $("#cmbprd").val();
    if (ctg == "---"){
        $('#prdcnt').html("<h4>Please choose type above</h4>");
    }else{
        prdHandler.slcProduct(ctg,function(items){//call select product function by sending category and receive return value items
            // preparing the return value items to be displayed in html page. 
            var tmp = "";
            items.forEach(obj => {
                var temp = "<div data-role = 'content' class = 'ui-content'>";
                Object.entries(obj).forEach(([key,value]) => {
                    switch(`${key}`){
                        case "_id": break;
                        case "type": break;
                        case "prdno": temp+= "<img src = 'img/"+`${value}`+".jpg' width = '100px' alt = '"+`${value}`+"'/>"; temp+= "<input type='text' id = 'noprd' value = '"+`${value}`+"' hidden/>"; break;
                        case "name": temp+= "<h3>"+`${value}`+"</h3>"; temp+= "<input type='text' id = 'nmprd' value = '"+`${value}`+"' hidden/>"; break;
                        case "price": temp+= "<h4> Price: $"+`${value}`+"</h4>";temp+= "<input type='text' id = 'prcprd' value = '"+`${value}`+"' hidden/>"; break;
                        default:
                            temp+= "<p>"+`${key}`+": "+`${value}`+"</p>";
                    }
                });
                temp+= "<div class = 'ui-field-contain'>Quantity: <input type='number' min='1' id = 'inum' data-clear-btn='true'/></div>";
                temp+= "<a class = 'ui-btn ui-icon-plus ui-btn-icon-left' id='btnBuy' onclick='trxBuy();'>Buy this item!!!</a></div>"; //adding buy button for customer who wants to buy the product and calling trxBuy() function.
                tmp+=temp; 
            });
            $("#prdcnt").html(tmp); //send prepared items to display in html page 
        });
            
        
    }
}
function trxBuy(){ //called by buyPrd() function and then collecting data from html after that send them to addTrans function in db.js to be inserted in transaction table. 
    var nop = $("#noprd").val();
    var nme = $("#nmprd").val();
    var num = $("#inum").val();
    var prc = $("#prcprd").val();
    trxHandler.addTrans(nop,nme,num,prc);
}

function selTrx(callback){ //a function to call function in db.js for collecting data transaction and process the return transaction items to display in html page  
    var items = new Array();
    trxHandler.slcTrans(function(items){
        var total = 0; //variable to store total shopping amount. 
        var tmp = "<table border='1'><tr><th>PrdNo</th><th>Name</th><th>Qty</th><th>Price</th><th>Total</th></tr>";
        items.forEach(obj => {
            var temp = "<tr>";
            Object.entries(obj).forEach(([key,value]) => {
                switch(`${key}`){
                    case "_id": break;
                    case "total":total += parseFloat(`${value}`);temp+= "<td>"+`${value}`+"</td>"; break;
                    default:
                        temp+= "<td>"+`${value}`+"</td>";
                }
            });
            temp+= "</tr>";
            tmp+=temp;
        });
        tmp+= "<tr><th colspan='3'>Total:</th><td colspan='2'>"+total+"</td></tr></table><br>"; //display total 
        // display payment methods
        tmp+= "<fieldset><legend>Payment Method: </legend><label><input type = 'radio' name = 'rdpay' value = 'cash' checked>Cash</label><label><input type = 'radio' name = 'rdpay' value = 'Paypal'>Paypal</label><label><input type = 'radio' name = 'rdpay' value = 'Credit'>Credit</label></fieldset>";
        $("#prdcnt").html(tmp);
    });



}